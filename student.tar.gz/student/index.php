<?php
session_start();
include("config.php");
if($_POST["Submit"]=="Register")
{
    $s_fname=$_POST["text_s_fname"];
    $s_lname=$_POST["text_s_lname"];
    $s_dob=$_POST["text_s_dob"];
    $s_uid=$_POST["text_s_uid"];
    $s_branch=$_POST["text_s_branch"];
    $s_year=$_POST["text_s_year"];
    $s_mob=$_POST["text_s_mob"];
    $s_eid=$_POST["text_s_eid"];
    $s_gender=$_POST["text_s_gender"];
    $s_address=$_POST["text_s_address"];
    $s_photo=$_POST["text_s_photo"];
    $s_password=$_POST["text_s_pass"];
    $_SESSION["s_fname"]=$_POST["text_s_fname"];

    //echo $_SESSION["username"];
    //exit;
    $str="insert into reg_detail(s_fname,s_lname,s_dob,s_uid,s_branch,s_year,s_mob,s_eid,s_gender,s_address,s_photo,s_password)value
    ('".$s_fname."','".$s_lname."','".$s_dob."','".$s_uid."','".$s_branch."','".$s_year."','".$s_mob."','".$s_eid."','".$s_gender."','".$s_address."','".$s_photo."','".$s_password."')";

    //echo $str;
    //exit;
    mysql_query($str);
    echo "<script>location.href='welcome.php'</script>";}?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <title>Registration</title>
    </head>
    <script language="javascript" type="text/javascript">
    function validate()
    {
    if(document.getElementById("text_s_fname").value=="")
    {
        alert("Please Enter Your First Name");
        document.getElementById("text_s_fname").focus();
        return false;
    }

    if(!(isNaN(document.registration.text_s_fname.value)))
    {
        alert("First Name has character only!");
        return false;
    }
    if(document.getElementById("text_s_lname").value=="")
    {
        alert("Please Enter Your Last Name");
        document.getElementById("text_s_lname").focus();
        return false;
    }

    if(!(isNaN(document.registration.text_s_lname.value)))
    {
        alert("Last Name has character only!");
        return false;
    }
    if(document.getElementById("text_s_dob").value=="")
    {
        alert("Please Enter Your D.O.B");
        document.getElementById("text_s_dob").focus();
        return false;
    }
   

    if(!(isNaN(document.registration.text_s_dob.value)))
    {
        alert("D.O.B has character only!");
        return false;
    }
    if(document.getElementById("text_s_uid").value=="")
    {
        alert("Please Enter Your Unique Id");
        document.getElementById("text_s_uid").focus();
        return false;
    }
   
    if(!(isNaN(document.registration.number_s_uid.value)))
    {
        alert("Unique Id has numeric only!");
        return false;
    }
    if(document.getElementById("text_s_branch").value=="")
    {
        alert("Please Enter Your branch");
        document.getElementById("text_s_branch").focus();
        return false;
    }
    if(!(isNaN(document.registration.text_s_branch.value)))
    {
        alert("Branch has character only!");
        return false;
    }
    if(document.getElementById("text_s_year").value=="")
    {
        alert("Please Enter Your Year");
        document.getElementById("text_s_year").focus();
        return false;
    }
    if(!(isNaN(document.registration.text_s_year.value)))
    {
        alert("Year has numeric only!");
        return false;
    }
    if(document.getElementById("text_s_mob").value=="")
    {
        alert("Please Enter Your Mobile Number");
        document.getElementById("text_s_mobile").focus();
        return false;
    }
    if((isNaN(document.registration.text_s_mob.value)))
    {
        alert("Mobile has numeric only!");
        return false;
    }
    var emailPat=/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i
    var emailid=document.getElementById("text_s_eid").value;
    var matchArray = emailid.match(emailPat);

    if (matchArray == null)
    {
        alert("Your email address seems incorrect. Please try again.");
        document.getElementById("text_s_eid").focus();
        return false;
    }
    if(document.getElementById("text_s_address").value=="")
    {
        alert("Please Enter Your Address");
        document.getElementById("text_s_address").focus();
        return false;
    }
 
    if(!(isNaN(document.registration.text_s_address.value)))
    {
        alert("Address has character only!");
        return false;
    }
    if(document.getElementById("text_s_pass").value=="")
    {
        alert("Please Enter Your Password");
        document.getElementById("text_s_pass").focus();
        return false;
    }

    if(document.getElementById("text_repass").value=="")
    {
        alert("Please ReEnter Your Password");
        document.getElementById("text_repass").focus();
        return false;
    }
    if(document.getElementById("text_repass").value!="")
    {
          if(document.getElementById("text_repass").value != document.getElementById("text_pass").value)
          {
               alert("Confirm Password doesnot match!");
               document.getElementById("text_repass").focus();
               return false;
          }
    }
    return true;
}
</script>
    <body>
        <form name="registration" action="index.php" method="post" onsubmit="return validate();">
        <center>
    <table border="1">
      <tr>
            <td colspan="2">User Registration Form </td>
     </tr>
       <tr>
        <td width="179">First Name<em>*</em></td>
    <td><label>
      <input name="text_s_fname" type="text" id="text_s_fname" />
    </label></td>
  </tr>
 <tr>
        <td width="179">Last Name<em>*</em></td>
    <td><label>
      <input name="text_s_lname" type="text" id="text_s_lname" />
    </label></td>
  </tr>
 <tr>
        <td width="179">D.O.B<em>*</em></td>
    <td><label>
      <input name="text_s_dob" type="text" id="text_s_dob" />
    </label></td>
  </tr>
 <tr>
        <td width="179">Unique Id<em>*</em></td>
    <td><label>
      <input name="text_s_uid" type="text" id="text_s_uid" />
    </label></td>
  </tr>
 <tr>
        <td width="179">Branch<em>*</em></td>
    <td><label>
      <input name="text_s_branch" type="text" id="text_s_branch" />
    </label></td>
  </tr>
 <tr>
        <td width="179">year<em>*</em></td>
    <td><label>
      <input name="text_s_year" type="text" id="text_s_year" />
    </label></td>
  </tr>
<tr>
    <td width="179">Phone/Mobile<em>*</em></td>
    <td><label>
      <input name="text_s_mob" type="text" id="text_s_mob" />
    </label></td>
  </tr>
            <tr>
    <td width="179">Email address <em>*</em></td>
    <td><label>
      <input name="text_s_eid" type="text" id="text_s_eid" />
    </label></td>
  </tr>
<tr>
    <td width="179">Gender  <em>*</em></td>
    <td><label>
      <input name="text_s_gender" type="text" id="text_s_gender" />
    </label></td>
  </tr>
  
  <tr>
    <td width="179">Address  <em>*</em></td>
    <td><label>
      <input name="text_s_address" type="text" id="text_s_address" />
    </label></td>
  </tr>
  <tr>
    <td width="179">Photo  <em>*</em></td>
    <td><label>
      <input name="text_s_photo" type="text" id="text_s_photo" />
    </label></td>
  </tr>
  
  
  <tr>
    <td>Password <em>*</em></td>
    <td><label>
      <input name="text_s_pass" type="password" id="text_s_pass" />
    </label></td>
  </tr>
  <tr>
    <td>Confirm Password <em>*</em></td>
    <td><label>
      <input name="text_repass" type="password" id="text_repass" />
    </label></td>
  </tr>
  <tr align="center">
    <td colspan="2"><label>
      <input type="submit" name="Submit" value="Register" />
    </label></td>
    </tr>
</table>
</center>
</form>
</body>
</html> 


